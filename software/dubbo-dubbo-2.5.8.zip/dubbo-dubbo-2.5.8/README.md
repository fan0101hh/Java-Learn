[![Build Status](https://travis-ci.org/alibaba/dubbo.svg?branch=master)](https://travis-ci.org/alibaba/dubbo) 
[![Gitter](https://badges.gitter.im/alibaba/dubbo.svg)](https://gitter.im/alibaba/dubbo?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)
![](https://img.shields.io/github/license/alibaba/dubbo.svg)
![](https://img.shields.io/maven-central/v/com.alibaba/dubbo.svg)

Please visit [dubbo.io](http://dubbo.io) for detailed documentation. Want to find more or contact us, see the following links.  
* [Affiliated projects](http://github.com/dubbo). More awesome projects facilitating dubbo.
* [Usage mailing list](https://groups.google.com/forum/#!forum/dubbo). For open-ended questions and discussion, see [Google Groups](https://sites.google.com/site/tomihasa/google-groups-faq#subscribetogroup) for how to subscribe.
* [Issue report](https://github.com/alibaba/dubbo/issues). Report a defect or feature request
* [Gitter channel](https://gitter.im/alibaba/dubbo). 
* [Contributing](https://github.com/alibaba/dubbo/blob/master/CONTRIBUTING.md). How to contribute.
